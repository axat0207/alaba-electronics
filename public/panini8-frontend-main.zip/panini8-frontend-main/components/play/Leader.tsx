import React from "react";

export default function Leader() {
  return (
    <div className=" max-lg:hidden">
      <div className="border-dotted border-2 border-grey-600 p-7 h-[100px] w-[300px]  ">
        <p className="">Leaderboard:</p>
      </div>
    </div>
  );
}
