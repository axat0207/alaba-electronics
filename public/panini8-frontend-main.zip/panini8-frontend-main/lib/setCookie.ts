export const setCookie = (token : any) => {
    console.log("function in setcookie", token)
}